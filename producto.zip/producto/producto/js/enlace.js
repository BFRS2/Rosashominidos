function sololetras(texto) {
  const regex = /^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+$/;
  return regex.test(texto);
}

document.getElementById("contactForm").addEventListener("submit", function(event) {
  const nombre = document.getElementById("nombre").value.trim();
  if (!sololetras(nombre)) {
    event.preventDefault();
    alert("El nombre solo debe contener letras.");
    return;
  }

  const pdfSeleccionado = document.querySelector('input[name="pdf"]:checked');
  if (!pdfSeleccionado) {
    event.preventDefault();
    alert("Por favor selecciona un PDF para descargar.");
    return;
  }
});
