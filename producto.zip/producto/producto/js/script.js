// Función que valida si el texto contiene solo letras (incluye letras acentuadas y la ñ)
function sololetras(texto) {
  // Expresión regular que permite letras mayúsculas, minúsculas, acentos, ñ y espacios
  const regex = /^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+$/;
  // Devuelve true si el texto cumple con la expresión regular, false si no
  return regex.test(texto);
}

// Se agrega un evento que se ejecuta cuando se envía el formulario con id "contactForm"
document.getElementById("contactForm").addEventListener("submit", function(event) {
  // Se obtiene el valor del campo "nombre" y se eliminan espacios al inicio y al final
  const nombre = document.getElementById("nombre").value.trim();

  // Se valida si el nombre contiene solo letras
  if (!sololetras(nombre)) {
    // Si no cumple con la validación, se detiene el envío del formulario
    event.preventDefault();
    // Se muestra un mensaje de advertencia al usuario
    alert("El nombre solo debe contener letras.");
  }
});
