document.addEventListener("DOMContentLoaded", function () {
    const lightbox = document.getElementById("lightbox");
    const imagenGrande = document.getElementById("imagen-grande");

    // Asegura que el lightbox esté oculto al inicio
    lightbox.style.display = "none";

    // Evento para mostrar la imagen ampliada
    document.querySelectorAll(".imagenes img").forEach(img => {
        img.addEventListener("click", function () {
            imagenGrande.src = this.src; // Asigna la imagen al lightbox
            lightbox.style.display = "flex"; // Muestra el lightbox
        });
    });

    // Cerrar el lightbox al hacer clic en la "X"
    document.querySelector(".cerrar").addEventListener("click", function () {
        lightbox.style.display = "none";
    });

    // Cerrar el lightbox si el usuario hace clic fuera de la imagen
    lightbox.addEventListener("click", function (event) {
        if (event.target === lightbox) {
            lightbox.style.display = "none";
        }
    });
});
