<?php
// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "formulario_usuarios");

// Verifica si hay error de conexión
if ($conexion->connect_error) {
    die("Error en la conexión: " . $conexion->connect_error);
}
// Sanitizar y validar entradas
$nombre = trim($_POST['nombre'] ?? '');
$correo = filter_var(trim($_POST['correo'] ?? ''), FILTER_VALIDATE_EMAIL);
$pdf = trim($_POST['pdf'] ?? '');
if ($nombre && $correo && $pdf) {
   $stmt = $conexion->prepare("INSERT INTO registros_pdf (nombre, correo, nombre_pdf) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nombre, $correo, $pdf);
// Validar que el pdf no este vacio
    if ($stmt->execute()) {
        echo "<script>alert('Datos guardados correctamente'); window.location.href = '../Productos_Ecologicos.pdf';</script>";
    } else {
        echo "Error al guardar: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Faltan datos válidos.";
}

$conexion->close();
?>
